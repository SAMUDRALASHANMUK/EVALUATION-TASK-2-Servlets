package com.msf.methods;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class DatabaseMethods {

	Logger log = LogManager.getLogger();

	/**
	 * Retrieves the available quantity of a stock from the portfolio table.
	 *
	 * @param connection the database connection
	 * @param symbol     the symbol of the stock
	 * @return the available quantity of the stock, or 0 if the symbol is not found
	 * @throws SQLException if a database error occurs
	 */
	public int getAvailableQuantity(Connection connection, String symbol) {
		String sql = "SELECT quantity FROM portfolio_table WHERE symbol = ?";
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			statement.setString(1, symbol);
			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					return resultSet.getInt("quantity");
				}
			} catch (SQLException e) {
				log.fatal(e);
			}
		} catch (SQLException e1) {

			log.fatal(e1);
		}
		return 0;
	}

	/**
	 * Retrieves the bid price for a given symbol from the stock price table.
	 *
	 * @param connection the database connection
	 * @param symbol     the symbol of the stock
	 * @return the bid price of the stock, or 0 if the symbol is not found
	 * @throws SQLException if a database error occurs
	 */
	public int getBidPrice(Connection connection, String symbol) {
		String sql = "SELECT bidPrice FROM stock_price WHERE symbol = ?";
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			statement.setString(1, symbol);
			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					return resultSet.getInt("bidPrice");
				}

			}
		} catch (SQLException e) {
			log.fatal(e);
		}

		return 0;
	}

	/**
	 * Retrieves the buy price for a given symbol from the portfolio table.
	 *
	 * @param connection the database connection
	 * @param symbol     the symbol of the stock
	 * @return the buy price of the stock, or 0 if the symbol is not found
	 * @throws SQLException if a database error occurs
	 */
	public int getBuyPrice(Connection connection, String symbol) {
		String sql = "SELECT buyPrice FROM portfolio_table WHERE symbol = ?";
		try (PreparedStatement statement = connection.prepareStatement(sql)) {
			statement.setString(1, symbol);
			try (ResultSet resultSet = statement.executeQuery()) {
				if (resultSet.next()) {
					return resultSet.getInt("buyPrice");
				}

			}
		} catch (Exception e) {
			log.fatal(e);
		}

		return 0;
	}

	/**
	 * Calculates the profit based on the buy price, sell price, and quantity of
	 * stocks sold.
	 *
	 * @param bidPrice  the buy price of the stock
	 * @param sellPrice the sell price of the stock
	 * @param quantity  the quantity of stocks sold
	 * @return the calculated profit
	 * 
	 */
	public int calculateProfit(int bidPrice, int sellPrice, int quantity) {

		return (bidPrice - sellPrice) * quantity;
	}

	/**
	 * Updates the portfolio table with the sold quantity and profit for a stock.
	 *
	 * @param connection   the database connection
	 * @param symbol       the symbol of the stock
	 * @param soldQuantity the quantity of stocks sold
	 * @param profit       the profit made from selling the stocks
	 * @throws SQLException if a database error occurs
	 */
	public void updatePortfolioTable(Connection connection, String symbol, int soldQuantity, int profit) {
		String sql = "UPDATE portfolio_table SET quantity = quantity - ?, TotalProfit = TotalProfit + ? WHERE symbol = ?";
		try (PreparedStatement statement = connection.prepareStatement(sql)) {

			statement.setInt(1, soldQuantity);
			statement.setInt(2, profit);
			statement.setString(3, symbol);
			statement.executeUpdate();

		} catch (SQLException e) {
			log.fatal(e);
		}

	}
}
